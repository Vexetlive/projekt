const uploadorder = document.querySelector('#upload');
const divOutput = document.querySelector('#divOutput');
const usernameInput = document.querySelector('#userName');
const passwordInput = document.querySelector('#Password');

document.getElementById("loginBtn")?.addEventListener('click', async (e) => {
    const userName = usernameInput.value; 
    const passWord = passwordInput.value;

    const fetchOptions = {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            userName,
            hashPassword: passWord
        })
    };

    const response = await fetch('http://127.0.0.1:8292/api/accounts/login', fetchOptions)
    const { errorMessage, account } = await response.json();

    if (response.ok) {
        const token = response.headers.get('x-authenticate-token')
        console.log('token', token)
        console.log('account', account)
        localStorage.setItem('token', token)
    
        window.location.href="loggedin.html";
    } else {
        divOutput.innerHTML = `Ooops. Something went wrong.<br/>${errorMessage}<br/>`;
    }
});



