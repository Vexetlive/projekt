const env = require('dotenv').config();
const config = require('config');
const express = require('express');
const app = express();
const cors = require('cors')
const customers = require('./routes/customers');
const orders = require('./routes/orders')
const accounts = require('./routes/accounts')

app.use(cors());
app.use(express.json());
app.use('/api/customers', customers)
app.use('/api/orders', orders)
app.use('/api/accounts' , accounts)

app.listen(config.get('port'), () => console.log(`Listening on port ${config.get('port')}...`));