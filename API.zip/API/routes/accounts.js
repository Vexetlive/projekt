const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const config = require('config');

const secret = config.get('jwt_secret_key');

const Account = require('../models/account');

router.post('/login', async (req, res) => {
    res.setHeader('Access-Control-Expose-Headers', 'x-authenticate-token'); //Her giver jeg adgang til headeren
    try {
        console.log("Du er nu ind på login siden")
        // previously Login.validate(req.body)
        const { error } = Account.validateCredentials(req.body);
        if (error) throw { statusCode: 400, errorMessage: error };

        // previously const loginObj = new Login(req.body)
        const accountAdmin = new Account(req.body);
        // previously const user = await Login.readByEmail(loginObj)
        const account = await Account.checkCredentials(accountAdmin);
        const sanitisedAccount = { 
            id: account.userId, 
            name: account.userName, 
            role: account.userRole
        }
        const token = await jwt.sign(sanitisedAccount, secret); //jwt står for json web token, der skal assignes to ting. 1. Hvilke data, 2. Crypt token

        res.setHeader('x-authenticate-token', token);  //

        // previously user
        return res.send({ account: sanitisedAccount });

    } catch (err) {
        console.log(err);
        // need to make the condition check sensible...
        if (!err.statusCode) return res.status(401).send(JSON.stringify({ errorMessage: 'Incorrect user email or password.' }));
        if (err.statusCode != 400) return res.status(401).send(JSON.stringify({ errorMessage: 'Incorrect user email or password.' }));
        return res.status(400).send(JSON.stringify({ errorMessage: err.errorMessage.details[0].message }));
    }
});

router.post('/', async (req, res) => {
    return res.status(404).send({ statusCode: 404, errorMessage: 'Not Found' })

    res.setHeader('Content-Type', 'application/json');
    try {
        // previously Login.validate(req.body)
        const { error } = Account.validate(req.body);
        if (error) throw { statusCode: 400, errorMessage: error };

        // previously const loginObj = new Login(req.body);
        const accountAdmin = new Account(req.body);
        accountAdmin.userRole = 'admin';
        // previously const user = await loginObj.create();
        const account = await accountAdmin.create();
        // previously user
        return res.send(JSON.stringify(account));
    } catch (err) {
        console.log(err);
        // need to make the condition check sensible...
        if (!err.statusCode) return res.status(500).send(JSON.stringify({ errorMessage: err }));
        if (err.statusCode != 400) return res.status(err.statusCode).send(JSON.stringify({ errorMessage: err }));
        return res.status(400).send(JSON.stringify({ errorMessage: err.errorMessage.details[0].message }));
    }
});

module.exports = router;