const express = require('express');
const router = express.Router();
const Order = require('../models/order');
const auth = require('../middleware/authenticate');


router.get('/', auth, async (req, res) => {
    try {
        const orders = await Order.readAll(); 
        console.log("Hello")
        return res.send(JSON.stringify(orders));
    }
    catch(err) {
      return res.status(500).send(JSON.stringify({ message: err }));
    }
});

router.post('/', async (req, res) => {
    res.setHeader('Content-Type', 'application/json');
    // need to validate the req.body (aka the data) that came with the request
    // if good, then try to send the data to the DB
    // if bad, then error with 400 bad request

    // validate
    const {
        userComment,
        userEmail
    } = req.body

    const { error } = Order.validate({
        userComment,
        userEmail
    });

    if (error) return res.status(400).send(JSON.stringify({ message: `Bad request. ${error.details[0].message}` }));

    const newOrder = new Order({
        userComment,
        userEmail,
        orderDate: Date.now(), //Gery lærte mig dette
        orderStatus: 'Not done',
        paymentStatus: 'Not paid',
        editorId: 3
    });

    try {
        const orders = await newOrder.create();
        return res.send({ orders });
    } catch (err) {
        return res.status(500).send(JSON.stringify({ message: err }));
    }

});
module.exports = router;