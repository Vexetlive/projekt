const express = require('express');
const router = express.Router();
const Customer = require('../models/customer');
const auth = require('../middleware/authenticate');

router.get('/', auth, async (req, res) => {
    try {
        const customers = await Customer.readAll(); 
        return res.send(JSON.stringify(customers));
    } catch(err) {
        return res.status(500).send(JSON.stringify({ message: err }));
    }
});

module.exports = router;