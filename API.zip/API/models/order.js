const sql = require('mssql');
const config = require('config');
const Joi = require('joi');
const { max } = require('lodash');
const con = config.get('dbConfig_UCN');

class Order {
    constructor(pfyOrder){
        this.orderId = pfyOrder.orderId;
        this.orderDate = pfyOrder.orderDate;
        this.userEmail = pfyOrder.userEmail;
        this.orderStatus = pfyOrder.orderStatus;
        this.paymentStatus = pfyOrder.paymentStatus;
        this.userComment=pfyOrder.userComment;
        this.editorId=pfyOrder.editorId;
    }
    static validate(pfyOrder){
        const schema = Joi.object({
            orderId: Joi.number()
                .integer(),  //DET ER JO IDENTIFIER SÅ HVAD ER MIN OG MAX?
            orderDate: Joi.number()
                .integer()
                .min (1),
            userEmail: Joi.string()
                .min(1)
                .max(255),
            orderStatus: Joi.string()
                .min(1)
                .max(12),
            paymentStatus: Joi.string()
                .min(1)
                .max(12),
            userComment: Joi.string()
                .max(5000), //infinity in my DB?
            editorId: Joi.number()
                .integer() //min og max for editor id?
        });

        return schema.validate(pfyOrder);

    }

    static readAll() {
        return new Promise((resolve, reject) => {
            (async () => {
                try {
                    const pool = await sql.connect(con);
                    const result = await pool.request()
                    .query(`SELECT * FROM pfyOrder`)

                    console.log(result);
                   const orders = [];
                    result.recordset.forEach(record => {
                        const eOrders = {
                            orderId: record.orderId,
                            orderDate: record.orderDate,
                            userEmail: record.FK_userEmail,
                            orderStatus: record.orderStatus,
                            paymentStatus: record.paymentStatus,
                            userComment: record.userComment,
                            editorId: record.FK_EditorId
                        }
                        
                        const {error} = Order.validate(eOrders);
                        if (error) throw {statusCode: 500, errorMessage: error.details[0].message}

                        orders.push(new Order(eOrders));
                     })

                    
                     resolve(orders);

                }
                catch (error) {
                    reject(error)
                }
                sql.close();
            })();
        })
    }
    create() {
        return new Promise((resolve, reject) => {
            (async () => {
                // need to connect to DB
                // query the DB (this case, INSERT with IDENTITY)
                // ...another(?) query to read out the new info
                // is there a result at all?
                // if yes, then check the format/reformat the result according to our needs (aka Book)
                // validate the object we created and see if it is indeed a 'Book'
                // if good, resolve with the book
                // if bad, reject with error
                // CLOSE THE DB connection!!!!!

                try {
                    const pool = await sql.connect(con);
                    const result00 = await pool.request()
                        .input('orderDate', sql.BigInt(), this.orderDate)
                        .input('FK_userEmail', sql.NVarChar(255), this.userEmail)
                        .input('orderStatus', sql.NVarChar(12), this.orderStatus)
                        .input('paymentStatus', sql.NVarChar(12), this.paymentStatus)
                        .input('userComment', sql.NVarChar(5000), this.userComment)
                        .input('FK_editorId', sql.Int(), this.editorId)

                        .query(`
                        INSERT INTO pfyOrder 
                        (orderDate, FK_userEmail, orderStatus, paymentStatus, userComment, FK_editorId)
                        VALUES (@orderDate, @FK_userEmail, @orderStatus, @paymentStatus, @userComment, @FK_editorId);
                        
                        SELECT *
                        FROM pfyOrder
                        WHERE orderId = SCOPE_IDENTITY();
                    `)


                    if (!result00.recordset[0]) throw { dberror: 'Something went wrong with the INSERT to pfyOrder' }
                    const newOrderId = result00.recordset[0].orderId;

                    const result = await pool.request()
                        .input('orderId', sql.Int(), newOrderId)
                        .query(`
                            SELECT *
                            FROM pfyOrder
                        `);

                    const orders = [];
                    result.recordset.forEach(record => {
                            const newOrder = {
                                orderId: record.orderId,
                                orderDate: record.orderDate,
                                userEmail: record.FK_userEmail,
                                orderStatus: record.orderStatus,
                                paymentStatus: record.paymentStatus,
                                userComment: record.userComment,
                                editorId: record.FK_EditorId 
                            }
                            orders.push(newOrder);
                        })
                    

                    const validOrders = [];
                    orders.forEach(order => {
                        const { error } = Order.validate(order);
                        if (error) throw { errorMessage: `Order.validate failed.` };

                        validOrders.push(new Order(order));
                    });

                    resolve(validOrders);

                } catch (error) {
                    console.error(error)
                    reject(error);
                }

                sql.close();
            })();
        });
    }
};

module.exports = Order;