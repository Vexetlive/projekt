const sql = require('mssql');
const config = require('config');
const Joi = require('joi');
const con = config.get('dbConfig_UCN');

class Customer {
    constructor(pfyCustomer) {
        this.userEmail = pfyCustomer.userEmail;
    }

    static validate(pfyCustomer) {
        const schema = Joi.object({
            userEmail: Joi.string()
                .max(255)
        });
        return schema.validate(pfyCustomer);
    }
/*
    static readbyId(userEmail) {
        return new Promise((resolve, reject) => {
            (async () => {
                try {
                    const pool = await sql.connect(con);
                    console.log('TESTING');
                    const result = await pool.request().query(`SELECT * FROM pfyCustomer`)

                    console.log(result);
                    resolve(result);

                }
                catch (error) {
                    reject(error)
                }
                sql.close();
            })();
        })
    } BRUG DET HER TIL ORDERS MÅSKE?
*/ 
    static readAll() {
        return new Promise((resolve, reject) => {
            (async () => {
                try {
                    console.log("about to connect to pool");
                    const pool = await sql.connect(con);
                    console.log('TESTING');
                    const result = await pool.request().query(`SELECT * FROM pfyCustomer`)

                    console.log(result);

                    const customers = [];
                    result.recordset.forEach(record => {
                        const eCustomer = {
                            userEmail: record.userEmail
                        }
                        
                        const {error} = Customer.validate(eCustomer);
                        if (error) throw {statusCode: 500, errorMessage: error.details[0].message}

                        customers.push(new Customer(eCustomer));
                    })

                    resolve(customers);

                }
                catch (error) {
                    reject(error)
                }
                sql.close();
            })();
        })
    }
};

module.exports = Customer;