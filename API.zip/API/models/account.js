const sql = require('mssql');
const config = require('config');
const Joi = require('joi');
const con = config.get('dbConfig_UCN');
const salt = parseInt(config.get('saltRounds'));
const bcrypt = require('bcryptjs');

class Account {
    constructor(pfyAccount) {
        this.userId = pfyAccount.userId;
        this.userName = pfyAccount.userName;
        this.hashPassword = pfyAccount.hashPassword;
        this.userRole = pfyAccount.userRole;
    }

    static validate(pfyAccount) {
        const schema = Joi.object({
            userId: Joi.number()
                .integer(),
            userName: Joi.string()
                .min(1)
                .max(24),
            hashPassword: Joi.string()
                .min(1)
                .max(255),
            userRole: Joi.string() //NO USER ROLE PERHAPS?
                .max(12)
        });
        return schema.validate(pfyAccount);
    }
    static validateCredentials(accountAdmin) {
        const schema = Joi.object({
            userName: Joi.string()
                .min(1)
                .max(24)
                .required(),
            hashPassword: Joi.string()
                .min(1)
                .max(255)
                .required()
            })
        

        return schema.validate(accountAdmin);
    }
    static async checkCredentials(accountAdmin) {
        // connect to DB
        // make a query (using the pool object)
        // check if there was a result
        // !!! -> check the hashed password with bcrypt!
        // if yes -> check format
        //  if format OK -> resolve
        // if no in any case, then throw and error and reject with error
        // CLOSE THE DB CONNECTION !!!!!!!!!!!!!!!!!!!!!!!!!!!!! !!!

        try {
            const pool = await sql.connect(con);
            const result = await pool.request()
            .input('userName', sql.NVarChar(255), accountAdmin.userName)
            .query(`
                SELECT * 
                FROM pfyAccount
                WHERE userName = @userName
            `);
            console.log(result);

            if (!result.recordset[0]) throw { statusCode: 404, errorMessage: 'User not found with provided credentials.' }
            if (result.recordset.length > 1) throw { statusCode: 500, errorMessage: 'Multiple hits of unique data. Corrupt database.' }

            const bcrypt_result = await bcrypt.compare(accountAdmin.hashPassword, result.recordset[0].hashPassword);
            if (!bcrypt_result) throw { statusCode: 404, errorMessage: 'User not found with provided credentials.' }

            const account = {
                userName: result.recordset[0].userName,
                userRole: result.recordset[0].userRole,
                userId: result.recordset[0].userId,
                hashPassword: result.recordset[0].hashPassword
                
            }
            // check if the format is correct!
            // will need a proper validate method for that

            // *** static validateResponse(accountResponse)
            const { error } = Account.validate(account);
            if (error) throw { statusCode: 500, errorMessage: 'Corrupt user account informaion in database.' }

            return account;

        } catch (error) {
            console.log(error);
            throw error;
        } finally {
            sql.close();
        }

    }

    static readByName(userName) {
        return new Promise((resolve, reject) => {
            (async () => {
                // connect to DB
                // query the DB (SELECT WHERE userEmail)
                // check if there is ONE result --> good
                //      else throw error
                // check format (validateResponse)
                // resolve with accountResponse
                // if any errors reject with error
                // CLOSE THE DB CONNECTION

                try {
                    const pool = await sql.connect(con);
                    const result = await pool.request()
                        .input('userName', sql.NVarChar(255), userName)
                        .query(`
                            SELECT * 
                            FROM pfyAccount
                            WHERE userName = @userName
                        `);
                    console.log(result);

                    // error contains statusCode: 404 if not found! --> important in create(), see below
                    if (!result.recordset[0]) throw { statusCode: 404, errorMessage: 'User not found with provided credentials.' }
                    if (result.recordset.length > 1) throw { statusCode: 500, errorMessage: 'Multiple hits of unique data. Corrupt database.' }

                    const accountAdmin = {
                        userName: result.recordset[0].userName,
                        userRole: result.recordset[0].userRole,
                        userId: result.recordset[0].userId,
                        hashPassword: result.recordset[0].hashPassword
                        
                    }

                    const { error } = Account.validate(accountAdmin);
                    if (error) throw { statusCode: 500, errorMessage: 'Corrupt user account informaion in database.' }

                    resolve(new Account(accountAdmin));

                } catch (error) {
                    console.log(error);
                    reject(error);
                }

                sql.close();
            })();
        });
    }
    
    create() {
        return new Promise((resolve, reject) => {
            (async () => {
                // but first! --> check if user exists already in the system!
                // *** code to check if user already exists in DB (based on userEmail)
                try {
                    const account = await Account.readByName(this.userName);    // checking if <this> account is already in the DB (by userEmail)
                    // if yes (aka no errors), then we have to abort creating it again --> REJECT with error: user exist
                    console.log(account);
                    reject({ statusCode: 409, errorMessage: 'Conflict: user name is already in use.' })
                } catch (error) {
                    // if there were any errors, need to check if it was 404 not found (check readByEmail above)
                    // basically we will reject on anything other than 404 (with the error)
                    // and do nothing if 404 --> we are good, the user's email is not in the DB yet, can carry on with creating a new account
                    console.log(error);
                    if (!error.statusCode) reject(error);
                    if (error.statusCode != 404) reject(error);

                    // if we made it so far, now we can try-catch what we came here for: create()
                    // yes, WITHIN the catch block!


                    // connect to DB
                    // make a query (INSERT INTO loginUser, SELECT with SCOPE_IDENTITY(), INSERT INTO loginPassword)
                    // if good, we have the userId in the result
                    // check format (again, we dont have a validator for that at the moment)
                    // resolve with user
                    // if anything wrong throw error and reject with error
                    // CLOSE THE DB CONNECTION
                    try {
                        // let's generate the hashedPassword
                        const hashPassword = await bcrypt.hash(this.hashPassword, salt);

                        const pool = await sql.connect(con);
                        const result00 = await pool.request()
                            .input('userName', sql.NVarChar(24), this.userName)
                            .input('hashPassword', sql.NVarChar(255), hashPassword)
                            .input('userRole', sql.NVarChar(12), this.userRole)
                            .query(`
                        INSERT INTO pfyAccount([userName], [hashPassword], [userRole])
                        VALUES (@userName, @hashPassword, @userRole);

                        SELECT *
                        FROM pfyAccount
                        WHERE userId = SCOPE_IDENTITY();
                    `);
                        console.log(result00);
                        if (!result00.recordset[0]) throw { statusCode: 500, errorMessage: 'Something went wrong, login is not created.' }

                        // previously user
                        const accountAdmin = {
                            userId: result00.recordset[0].userId,
                            userName: result00.recordset[0].userName,
                            userRole: result00.recordset[0].userRole
                        }
                        // check if the format is correct!
                        // will need a proper validate method for that

                        // *** static validateResponse(accountResponse)
                        const { error } = Account.validate(accountAdmin);
                        console.log(error);
                        if (error) throw { statusCode: 500, errorMessage: 'Corrupt user account informaion in database.' }

                        // previously resolve(user)
                        resolve(new Account(accountAdmin));

                    } catch (error) {
                        console.log(error);
                        reject(error);
                    }
                }

                sql.close();
            })();
        });
    }

}
module.exports = Account;